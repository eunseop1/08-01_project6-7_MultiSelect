package kr.manamana.select.vo;

import lombok.Data;

@Data
public class AreaVO {
	private String id;
	private String name;
}
